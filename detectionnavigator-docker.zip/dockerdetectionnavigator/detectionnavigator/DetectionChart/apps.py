from django.apps import AppConfig

class DetectionChartConfig(AppConfig):
    name = 'DetectionChart'
